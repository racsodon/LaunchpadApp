﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DragonController : MonoBehaviour {

    public GameObject player;

    //Rotate values to math with
    public GameObject lookAtPlayer;
    private Vector3 lookTarget;
    private Vector3 currentRotation;

    //Movement values to be set in editor
    public float maxSpeed;
    public float accelerationSpeed;
    public float brakeSpeed;
    public float minSpeed;
    public float turnSpeed;
    public float retreatDistance;
    public float retreatLength;

    //Private values for the character controller and forward movement
    private CharacterController cc;
    private Vector3 moveSpeed = Vector3.zero;
    private Vector3 playerDistance;
    private float currentSpeed;
    private float retreatTimer;
    private bool isSeeking = true;
    
    void Start () {
        cc = GetComponent<CharacterController>();
    }
	

	void Update () {

        playerDistance = (player.transform.position - transform.position);

        /*
        Two AI states:
        Seeking: Rotate towards the player and accelerate.
        !Seeking: Stop rotating and brake.
                 
        Seeking is the default state, and it flips to !Seeking when it gets close to the player
        */


        // If dragon is following player and gets too close, disable turning
        if (isSeeking && playerDistance.magnitude < retreatDistance)
        {
            isSeeking = false;
            retreatTimer = 0;
        }


        // After a length of time (retreatlength), enable turning again
        if (retreatTimer >= retreatLength)
        {
            isSeeking = true;
        }
        else if(!isSeeking)
        {
            retreatTimer += Time.deltaTime;
        }


        if (isSeeking)
        {
            lookTarget = lookAtPlayer.transform.rotation.eulerAngles;

            currentRotation = new Vector3(
                 Mathf.LerpAngle(currentRotation.x, lookTarget.x, turnSpeed * Time.deltaTime),
                 Mathf.LerpAngle(currentRotation.y, lookTarget.y, turnSpeed * Time.deltaTime),
                 Mathf.LerpAngle(currentRotation.z, lookTarget.z, turnSpeed * Time.deltaTime));

            transform.eulerAngles = currentRotation;

            currentSpeed += accelerationSpeed;
        }
        else
        {
            currentSpeed -= brakeSpeed;
        }

        //Limit speed from going out of bounds
        if (currentSpeed > maxSpeed)
        {
            currentSpeed = maxSpeed;
        }
        else if (currentSpeed < minSpeed)
        {
            currentSpeed = minSpeed;
        }

        // Apply acceleration
        moveSpeed = transform.forward * currentSpeed;
        cc.Move(moveSpeed * Time.deltaTime);

    }

    
}
