﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MinimapFollow : MonoBehaviour {

    public GameObject playerBird;
    public float cameraHeight;

	// Use this for initialization
	void Start () {
		

	}
	
	// Update is called once per frame
	void Update () {

        transform.position = new Vector3(playerBird.transform.position.x, playerBird.transform.position.y + cameraHeight, playerBird.transform.position.z);
    }
}
