﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour {

    public Text scoreText;
    public int totalCoins;
    public int coinsToUnlock;

    bool isLocked = true;
    int coinsCollected = 0;
    int coinsLeft;
    string winText;

	
	void Start () {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }
	
	
	void Update () {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            CursorLock();
        }
        if (Input.GetKeyDown(KeyCode.Backspace))
        {
            Application.Quit();
        }

        // How many coins does the player need to unlock the exit?
        coinsLeft = coinsToUnlock - coinsCollected;
        // Clamp lower value to 0
        if (coinsLeft <= 0)
        {
            coinsLeft = 0;
        }

        if (coinsCollected >= coinsToUnlock)
        {
            winText = "\n" + "You Win!" + "\n" + "Collect the other coins or quit now.";
        }
        else
        {
            winText = "\n" + "Coins needed to win: " + coinsLeft;
        }

        scoreText.text = "Coins collected: " + coinsCollected + "/" + totalCoins + winText;
	}






    void CursorLock() {
        if (isLocked)
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            isLocked = false;
        }
        else
        {
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
            isLocked = true;
        }
    }

    public void CoinCollected(GameObject coinObject)
    {
        coinObject.SetActive(false);
        coinsCollected++;
    }
}
