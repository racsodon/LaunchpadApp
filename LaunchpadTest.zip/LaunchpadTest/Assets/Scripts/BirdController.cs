﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BirdController : MonoBehaviour {

    //Movement values to be set in editor
    public float maxSpeed;
    public float accelerationSpeed;
    public float brakeSpeed;
    public float stabilizeSpeed;
    public float turnSpeedLeftRight;
    public float turnSpeedUpDown;
    public float rollSpeedLeftRight;

    //Option for the player
    public bool isInverted = false;

    //Private values for the character controller and forward movement
    private CharacterController cc;
    private float currentSpeed;
    private Vector3 moveSpeed = Vector3.zero;

    //For Coin Collection
    private GameObject gameControl;



    void Start () {
        cc = GetComponent<CharacterController>();
        gameControl = GameObject.Find("GameController");
    }
	

	void Update () {

        // Check for inverted controls
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            if (isInverted)
            {
                isInverted = false;
            }
            else
            {
                isInverted = true;
            }
        }



        //
        // Rotation
        //

        //Pitch with inversion
        float pitch = 0f;

        if (isInverted)
        {
            if (Input.GetKey("w"))
            {
                pitch = -turnSpeedUpDown * Time.deltaTime;
            }
            else if (Input.GetKey("s"))
            {
                pitch = turnSpeedUpDown * Time.deltaTime;
            }
            pitch -= (Input.GetAxis("Mouse Y") * turnSpeedUpDown * Time.deltaTime);
        }
        else
        {
            if (Input.GetKey("w"))
            {
                pitch = turnSpeedUpDown * Time.deltaTime;
            }
            else if (Input.GetKey("s"))
            {
                pitch = -turnSpeedUpDown * Time.deltaTime;
            }
            pitch += (Input.GetAxis("Mouse Y") * turnSpeedUpDown * Time.deltaTime);
        }



        // Yaw
        float yaw = Input.GetAxis("Mouse X") * turnSpeedLeftRight * Time.deltaTime;

        // Roll
        float roll = 0f;

        if (Input.GetKey("a"))
        {
            roll = rollSpeedLeftRight * Time.deltaTime;
        }
        else if (Input.GetKey("d"))
        {
            roll = -rollSpeedLeftRight * Time.deltaTime;
        }

        //Rotate
        transform.Rotate(new Vector3(roll, yaw, pitch));

       







        //
        //   Acceleration below
        //

        //Check for acceleration/deceleration input
        if (Input.GetKey("mouse 0"))
        {
            currentSpeed += accelerationSpeed;
        }
        else if(Input.GetKey("mouse 1"))
        {
            currentSpeed -= brakeSpeed;
        }

        //Limit speed from going out of bounds
        if (currentSpeed > maxSpeed)
        {
            currentSpeed = maxSpeed;
        }
        else if (currentSpeed < 0f)
        {
            currentSpeed = 0f;
        }

        //Apply acceleration
        moveSpeed = transform.right * currentSpeed;
        cc.Move(moveSpeed * Time.deltaTime);
	}

    // Collecting Coins
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Coin"))
        {
            gameControl.GetComponent<GameController>().CoinCollected(other.gameObject);
        }
        else if (true)
        {
            if (other.gameObject.CompareTag("Dragon"))
            {
                SceneManager.LoadSceneAsync(SceneManager.GetActiveScene().buildIndex);
            }
        }
    }
}
